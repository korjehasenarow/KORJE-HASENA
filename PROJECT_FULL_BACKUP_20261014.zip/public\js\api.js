// API Client for Karje Hasana Foundation

const API = {
  baseUrl: '',

  async request(endpoint, options = {}) {
    const url = this.baseUrl + endpoint;
    const headers = options.headers || {};

    try {
      const savedUser = localStorage.getItem('kh_user');
      if (savedUser) {
        const u = JSON.parse(savedUser);
        if (u.role && !headers['x-user-role']) headers['x-user-role'] = u.role;
        if (u.id && !headers['x-user-id']) headers['x-user-id'] = u.id;
      }
    } catch (e) {}

    if (!(options.body instanceof FormData) && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }

    try {
      const response = await fetch(url, { ...options, headers });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || data.error || 'অনুরোধটি সম্পন্ন করা সম্ভব হয়নি।');
      }
      return data;
    } catch (err) {
      console.error(`API Error [${endpoint}]:`, err);
      throw err;
    }
  },

  // Auth
  login: (credentials) => API.request('/api/auth/login', { method: 'POST', body: JSON.stringify(credentials) }),

  // Settings
  getSettings: () => API.request('/api/settings'),
  updateSettings: (settings) => API.request('/api/settings', { method: 'PUT', body: JSON.stringify(settings) }),

  // Public
  getPublicSummary: () => API.request('/api/public/summary'),
  submitPublicPayment: (formData) => API.request('/api/public/submit-payment', { method: 'POST', body: formData }),
  submitPublicApplication: (formData) => API.request('/api/public/submit-application', { method: 'POST', body: formData }),

  // Dashboard Stats
  getDashboardStats: () => API.request('/api/dashboard/stats'),

  // Donors
  getDonors: (params = '') => API.request('/api/donors' + (params ? '?' + params : '')),
  getDonor: (id) => API.request(`/api/donors/${id}`),
  createDonor: (data) => API.request('/api/donors', { method: 'POST', body: data instanceof FormData ? data : JSON.stringify(data) }),

  // Committee (Managing & Advisory Board)
  getCommittee: () => API.request('/api/committee'),
  addCommitteeMember: (formData) => API.request('/api/committee', { method: 'POST', body: formData }),
  updateCommitteeMember: (id, formData) => API.request(`/api/committee/${id}`, { method: 'PUT', body: formData }),
  deleteCommitteeMember: (id, params = '') => API.request(`/api/committee/${id}` + (params ? '?' + params : ''), { method: 'DELETE' }),

  // Donations
  getDonations: (params = '') => API.request('/api/donations' + (params ? '?' + params : '')),
  recordDonation: (data) => API.request('/api/donations', { method: 'POST', body: JSON.stringify(data) }),
  verifyDonation: (id, data) => API.request(`/api/donations/${id}/verify`, { method: 'POST', body: JSON.stringify(data) }),

  // bKash Submissions
  getBkashSubmissions: () => API.request('/api/bkash-submissions'),
  verifyBkashSubmission: (id, data) => API.request(`/api/bkash-submissions/${id}/verify`, { method: 'POST', body: JSON.stringify(data) }),
  rejectBkashSubmission: (id, data) => API.request(`/api/bkash-submissions/${id}/reject`, { method: 'POST', body: JSON.stringify(data) }),

  // Applications
  getApplications: (params = '') => API.request('/api/applications' + (params ? '?' + params : '')),
  getApplication: (id) => API.request(`/api/applications/${id}`),
  verifyApplication: (id, data) => API.request(`/api/applications/${id}/verify`, { method: 'POST', body: JSON.stringify(data) }),
  approveApplication: (id, data) => API.request(`/api/applications/${id}/approve`, { method: 'POST', body: JSON.stringify(data) }),
  rejectApplication: (id, data) => API.request(`/api/applications/${id}/reject`, { method: 'POST', body: JSON.stringify(data) }),

  // Loans & Disbursements
  getLoans: (params = '') => API.request('/api/loans' + (params ? '?' + params : '')),
  getLoan: (id) => API.request(`/api/loans/${id}`),
  disburseLoan: (data) => API.request('/api/loans/disburse', { method: 'POST', body: JSON.stringify(data) }),
  extendLoan: (id, data) => API.request(`/api/loans/${id}/extend`, { method: 'POST', body: JSON.stringify(data) }),

  // Repayments
  recordRepayment: (data) => API.request('/api/repayments', { method: 'POST', body: JSON.stringify(data) }),

  // Expenses
  getExpenses: () => API.request('/api/expenses'),
  createExpense: (data) => API.request('/api/expenses', { method: 'POST', body: JSON.stringify(data) }),

  // Transfers
  transferAccount: (data) => API.request('/api/transfers', { method: 'POST', body: JSON.stringify(data) }),

  // Accounts & Funds
  getAccounts: () => API.request('/api/accounts'),
  getFunds: () => API.request('/api/funds'),

  // Reports
  getCashbookReport: (params = '') => API.request('/api/reports/cashbook' + (params ? '?' + params : '')),
  getIncomeExpenditureReport: (params = '') => API.request('/api/reports/income-expenditure' + (params ? '?' + params : '')),
  getBalanceSheet: () => API.request('/api/reports/balance-sheet'),

  // Notifications
  getNotifications: () => API.request('/api/notifications'),
  markNotificationRead: (id) => API.request(`/api/notifications/${id}/read`, { method: 'POST' }),
  runReminderCheck: () => API.request('/api/notifications/run-check', { method: 'POST' }),

  // Audit Logs
  getAuditLogs: () => API.request('/api/audit-logs'),

  // Restore Database
  restoreBackup: (formData) => API.request('/api/system/restore', { method: 'POST', body: formData })
};

// Global Bengali number formatter helper
function bnNum(num) {
  if (num === null || num === undefined) return '০';
  const bn = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  const formatted = Number(num).toLocaleString('en-US');
  return String(formatted).replace(/[0-9]/g, w => bn[+w]);
}

// Global BDT Currency Formatter
function formatBDT(amount) {
  return '৳ ' + bnNum(amount);
}
